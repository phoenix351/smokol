<?php

namespace App\Libraries;
require(APPPATH . 'ThirdParty/fpdf/fpdf.php');
class Pdf extends FPDF
{

  
}
