<?php



namespace App\Controllers;

use App\Models\KendaraanDinasModel;
use App\Models\BarangITModel;
use App\Models\PegawaiModel;
use App\Models\PengajuanModel;
use App\Models\PenggunaModel;
use App\Models\GrupModel;
use CodeIgniter\API\ResponseTrait;
use CodeIgniter\RESTful\ResourceController;

class User extends ResourceController
{
   

}
