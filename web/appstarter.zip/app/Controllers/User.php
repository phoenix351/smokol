<?php



namespace App\Controllers;

use App\Models\KendaraanDinasModel;
use App\Models\BarangITModel;
use App\Models\PegawaiModel;
use App\Models\BarangModel;
use App\Models\PengajuanModel;
use App\Models\PenggunaModel;
use App\Models\GrupModel;
use CodeIgniter\API\ResponseTrait;
use CodeIgniter\RESTful\ResourceController;
use App\Controllers\Memo;
use App\ThirdParty\fpdf\FPDF;

class User extends ResourceController
{

    use ResponseTrait;
    function __construct()
    {
        $this->pdf = new FPDF();
        $this->request = service('request');
    }


    protected $app_name = "SMOKOL";
    protected $helpers = ['auth'];
    protected $kondisi_list = [
        "Baik",
        "Rusak Ringan",
        "Rusak Berat"
    ];
    protected $merk_list = [
        "ASUS", "HP", "DELL", "LENOVO", "Lainnya"
    ];
    protected $merk_kbm = [
        "HONDA", "YAMAHA", "MITSUBISHI", "CHEVROLET", "SUZUKI", "TOYOTA"
    ];

    protected $jenis_list = [
        "Laptop", "PC", "Tablet", "UPS", "Printer", "Scanner", "Lainnya"
    ];
    protected $tipe_list = [
        "Asus All In One PC Series", "Optiplex 3010 DT", "Optiplex 3020 Micro", "Optiplex 3040 Micro", "Optiplex 330", "Optiplex 780", "Azura Z3 (Rakitan)", "DX2310 MT (Pavilion)", "Prodesk 41 G5 SFF", "Z4", "Lenovo All In One PC", "Think Centre M710t", "Think Centre M720t", "Think Centre M80", "Lainnya",
    ];
    protected $type_list_kendaraan = [
        "Mobil",
        "Sepeda Motor"
    ];

    protected $room_list = [
        "IPDS-Ruang Koordinator",
        "IPDS-Ruang Pegawai",
        "IPDS-Ruang Pengolahan",
        "Umum-Ruang Pegawai Umum",
        "Umum-Lobby",
        "IPDS-Pelayanan Statistik Terpadu",
        "Umum-Ruang Pegawai Perencanaan",
        "Umum-Ruang Pegawai PBJ",
        "Umum-Ruang Pegawai Keuangan",
        "Umum-Ruang Kepala Bagian",
        "Umum-Ruang Arsip",
        "Umum-Ruang Pegawai SDM",
        "Statistik Produksi-Ruang Koordinator",
        "Statistik Produksi-Ruang Pegawai",
        "Statistik Sosial-Ruang Koordinator",
        "Statistik Sosial-Ruang Pegawai",
        "Ruang Mako SP2020",
        "Aula",
        "Ruang Kepala BPS",
        "Umum-Ruang Sekretaris",
        "Ruang Vicon",
        "Nerwilis-Ruang Koordinator",
        "Nerwilis-Ruang Pegawai",
        "Statistik Distribusi-Ruang Koordinator",
        "Statistik Distribusi-Ruang Pegawai",
        "Lainnya"
    ];
    protected $os_list = [
        "Windows 10",
        "Windows 8",
        "Windows 7",
        "Windows XP",
        "Ubuntu",
        "CentOS",
        "Tidak Memakai OS",
        "Lainnya"
    ];
    protected $fungsi_list = [
        'Kepala Kantor',
        'Bagian Umum',
        'Fungsi Statistik Sosial',
        'Fungsi Statistik Produksi',
        'Fungsi Statistik Distribusi',
        'Fungsi Neraca Wilayah dan Analisis Statistik',
        'Fungsi IPDS',
    ];
    protected $jabatan_list  = [
        'Kepala BPS Provinsi',
        'Kepala Bagian',
        'Koordinator Fungsi',
        'Sub Koordinator Fungsi',
        'Staf Pelaksana',
        'PPNPN'
    ];


    public function index()
    {
        $it = new BarangITModel();
        $kbm = new KendaraanDinasModel();
        $barang = new BarangModel();


        if (logged_in()) {
            $sum_ = $barang->getKondisiSum(user()->id);
            $data = [
                'barang_it'  => $it->getBarangByUser(user()->id),

                'sum' => $sum_,
                'title' => 'Daftar Barang',
                "app_name" => $this->app_name,
                "page_name" => "Dashboard",
                "uri" => $this->uri = service('uri')
            ];
        } else {
            $sum_ = $barang->getKondisiSum();
            $data = [
                'barang_it'  => $it->getBarangByUser(),

                'sum' => $sum_,
                'title' => 'Daftar Barang',
                "app_name" => $this->app_name,
                "page_name" => "Dashboard",
                "uri" => $this->uri = service('uri')
            ];
        }

        return view('user/index', $data);
    }
    public function madang()
    {


        $pass_arr = array(
            '123', '123', 'babang88', 'hahotan', '123', '123', '123', '123',
            '123', 'simon', '123', 'hase', '123', 'na2imoet', '123', '123',
            '123', 'enggelin', 'rendiarmi', '123', '123', '123', 'ocha45',
            '12345', '123', 'remi606', '123', '220882', '123', '123', '1123',
            'uneth', 'florentz', 'stela', 'juliana', '340051208', 'frisda',
            'dame', 'fitria', 'prima', 'priska', '123', 'randy10', 'admin7101',
            'admin7102', 'admin7103', 'admin7104', 'admin7105', 'admin7106',
            'admin7107', 'admin7108', 'admin7171', 'admin7172', 'admin7173',
            'admin7174', 'suharsi', 'windha', 'mohsam1983', 'sumbodo', '4dm1n',
            'radjid', '12345', '340055881', 'misterwan', 'karni', '50235',
            '56374', '19222', 'dhila', '340020214', 'dwijo', 'jump4new',
            'Anton', 'Dadan', '340058546', '340058222', '340059045',
            '340058482', 'christiant7', 'Untari', 'Pande', 'nabella',
            '340058281', 'ida', '340051380', 'dendi'
        );
        echo "[";
        foreach ($pass_arr as $pass) {
            echo  "'" . user()->hashPassword($pass) . "',";
        }
    }
    function Header($nomor, $tanggal)
    {
        // Logo

        $this->pdf->Image('assets/img/logo-ct.png', 90, 6, 30);
        // Arial bold 15
        $this->pdf->SetFont('Arial', 'B', 13);
        // Move to the right

        // Title
        $this->pdf->Ln(25);
        $this->pdf->Cell(0, 10, 'BADAN PUSAT STATISTIK PROVINSI SULAWESI UTARA', 0, 0, 'C');
        $this->pdf->Ln(7);
        $this->pdf->Cell(0, 10, 'MEMO PENGAJUAN USULAN PERBAIKAN BARANG IT', 0, 0, 'C');
        $this->pdf->SetFont('Arial', '', 11);
        $this->pdf->Ln(7);
        $this->pdf->Cell(0, 10, 'Nomor : ' . $nomor . "     Tanggal : " . $tanggal, 0, 0, 'C');



        // Line break
        $this->pdf->Ln(20);
    }
    function Body($nama_barang, $jenis_barang, $nomor_seri, $nib, $keluhan)
    {
        $this->pdf->SetFont('Arial', '', 11);
        $this->pdf->SetX(20);
        $this->pdf->Cell(60, 10, 'Jenis Barang', 0, 0, 'L');
        $this->pdf->Cell(60, 10, ': ' . $jenis_barang, 0, 0, 'L');
        $this->pdf->Ln(10);
        $this->pdf->SetX(20);
        $this->pdf->Cell(60, 10, 'Nama Barang', 0, 0, 'L');
        $this->pdf->Cell(60, 10, ': ' . $nama_barang, 0, 0, 'L');
        $this->pdf->Ln(10);
        $this->pdf->SetX(20);
        $this->pdf->Cell(60, 10, 'Nomor Seri', 0, 0, 'L');
        $this->pdf->Cell(60, 10, ': ' . $nomor_seri, 0, 0, 'L');
        $this->pdf->Ln(10);
        $this->pdf->SetX(20);
        $this->pdf->Cell(60, 10, 'Nomor Induk Barang', 0, 0, 'L');
        $this->pdf->Cell(60, 10, ': ' . $nib, 0, 0, 'L');
        $this->pdf->Ln(10);
        $this->pdf->SetX(20);
        $this->pdf->Cell(60, 10, 'Keluhan', 0, 0, 'L');
        $this->pdf->MultiCell(100, 10, ': ' . $keluhan);
        $this->pdf->Ln(30);
    }

    // Page footer
    function Footer($penerima, $penyerah, $tanggal_diajukan, $tanggal_diproses)
    {
        // Position at 1.5 cm from bottom

        // Arial italic 8
        $this->pdf->SetFont('Arial', '', 11);
        // Page number
        $this->pdf->SetX(30);
        $this->pdf->Cell(60, 10, 'Yang Menerima,', 0, 0, 'C');
        $this->pdf->SetX(-70);
        $this->pdf->Cell(60, 10, 'Yang Menyerahkan, ', 0, 0, 'C');
        $this->pdf->Ln(30);
        $this->pdf->SetX(30);
        $this->pdf->Cell(60, 10, $penerima, 0, 0, 'C');
        $this->pdf->SetX(-70);
        $this->pdf->Cell(60, 10, $penyerah, 0, 0, 'C');
        $this->pdf->Ln(6);
        $this->pdf->SetX(20);
    }


    // Instanciation of inherited class


    public function cetak($id = null)
    {
        $pengajuan  = new PengajuanModel();
        $barang = $pengajuan->getPengajuanById($id)[0];
        $result = date('d/m/Y');
        $bulan = date('m');
        $tahun = date('Y');


        $data = [
            'nomor_surat' => 'PTI.' . $barang['id'] . '/BPS7100/' . $bulan . '/' . $tahun,
            'nama_barang' => $barang['merk'] . ' ' . $barang['tipe'],
            "jenis_barang" => $barang['jenis'],
            "nomor_seri" => $barang['nomor_seri'],
            "nib" => $barang['nib'],
            "keluhan" => $barang['keluhan'],
            "nama_pemakai" => $barang['nama_lengkap'],
            "nama_admin" => user()->nama_lengkap,
            "tanggal_diajukan" => $barang['tanggal_diajukan'],
            "tanggal_diproses" => $barang['tanggal_diproses'],
            "tanggal" => $result
        ];




        // membuat halaman baru
        $this->pdf->AliasNbPages();
        $this->pdf->AddPage();
        $this->Header($data["nomor_surat"], $data["tanggal"]);
        $this->Body($data["nama_barang"], $data['jenis_barang'], $data['nomor_seri'], $data['nib'], $data['keluhan']);
        $this->Footer($data['nama_admin'], $data['nama_pemakai'], $data['tanggal_diajukan'], $data['tanggal_diproses']);
        $this->pdf->SetFont('Times', '', 12);



        $this->response->setHeader('Content-Type', 'application/pdf');
        $this->pdf->Output();
    }
    public function pengguna_balik_barang()
    {

        $barangModel = new BarangModel();

        $id = $this->request->getPost('barang_id');
        $barangModel->balik_barang_pengguna($id);
        //return success
        return redirect()->to(base_url('user/pengguna_barangit'))->with('message', 'Berhasil Mengembalikan Barang ke Gudang');
    }
    public function profile()
    {
        $data = [
            "app_name" => $this->app_name,
            "page_name" => "Profile",
            "uri" => $this->uri = service('uri')
        ];
        return view('user/profile', $data);
    }
    public function rekap()
    {
        $it = new BarangITModel();
        $kbm = new KendaraanDinasModel();
        $data = [
            'title' => 'Rekapitulasi Barang',
            'rekap_it' => $it->getRekap(),
            'rekap_biaya' => $it->getRekapBiaya(),
            "app_name" => $this->app_name,
            "page_name" => "Rekapitulasi",
            "uri" => $this->uri = service('uri')
        ];
        return view("user/rekap", $data);
    }
    public function kelola_barangit()
    {
        $it = new BarangITModel();
        $peg = new PenggunaModel();

        $data = [
            'barang'  => $it->getBarangById(),
            'daftar_nip' => $peg->getAllNip(),
            'title' => 'Daftar Barang IT',
            'os_list' => $this->os_list,
            'room_list' => $this->room_list,
            'merk_list' => $this->merk_list,
            'tipe_list' => $this->tipe_list,
            "app_name" => $this->app_name,
            "page_name" => "Kelola Barang IT",
            "uri" => $this->uri = service('uri')
        ];
        return view('user/kelola_barangit', $data);
    }
    protected function tambahBarang($data)
    {
        $barang = new BarangModel();

        //"tahunPeroleh" => $request->getPost('tahunPeroleh'),

        $barang->set($data);
        $barang->insert();
        return $barang->insertID;
    }

    public function tambahBarangIT()
    {
        $it = new BarangITModel();
        $request = service('request');


        $data_it = [
            'id' => $this->insertBarangForm(),
            'os' => $request->getPost('os')
        ];
        $it->set($data_it);
        $it->insert();

        return redirect()->to($request->getPost('url'))->with('message', 'Berhasil Menambahkan satu barang IT');
    }
    public function ubah_barangitByUser()
    {
        $barangModel = new BarangModel();
        $it = new BarangITModel();
        $request = service("request");
        $id = $request->getPost("id");
        #cek 
        if (user()->nip != $it->getBarangById($id)[0]['nip_pemakai']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }


        $data = [
            "jenis" => $request->getPost('jenis'),
            "merk" => $request->getPost('merk'),
            "tahun" => $request->getPost('tahun'),
            "kondisi" => $request->getPost('kondisi'),
            "nomor_seri" => $request->getPost('nomor_seri'),
            "nib" => $request->getPost('nib'),
            "lokasi" => $request->getPost('lokasi'),

            "tipe" => $request->getPost('tipe'),

        ];

        $up1  = $barangModel->update($id, $data);
        $data2 = [
            "os" => $request->getPost('os'),
        ];
        $up2 = $it->update($id, $data2);
        if ($up2 && $up1) {
            return redirect()->to($request->getPost('url'))->with('message', 'Berhasil mengubah data barang!');
        } else {
            return redirect()->to($request->getPost('url'))->with('error', 'Gagal mengubah data barang!');
        }
    }
    public function ubahBarangIT()
    {
        $barangModel = new BarangModel();
        $it = new BarangITModel();

        $request = service("request");

        $data = [
            "jenis" => $request->getPost('jenis'),
            "merk" => $request->getPost('merk'),
            "tahun" => $request->getPost('tahun'),
            "kondisi" => $request->getPost('kondisi'),
            "nomor_seri" => $request->getPost('nomor_seri'),
            "nib" => $request->getPost('nib'),
            "lokasi" => $request->getPost('lokasi'),
            "nip_pemakai" => $request->getPost('nip_pemakai'),
            "tipe" => $request->getPost('tipe'),

        ];
        $id = $request->getPost("id");
        $up1  = $barangModel->update($id, $data);
        $data2 = [
            "os" => $request->getPost('os'),
        ];
        $up2 = $it->update($id, $data2);
        if ($up2 && $up1) {
            return redirect()->to($request->getPost('url'))->with('message', 'Berhasil mengubah data barang!');
        } else {
            return redirect()->to($request->getPost('url'))->with('error', 'Gagal mengubah data barang!');
        }
    }

    public function hapusBarangIT()
    {
        $request = service('request');
        $id = $request->getPost('id');

        $model = new BarangITModel();
        if (isset($id)) {
            $hapus = $model->where('id', $id)->delete();
            if ($hapus) {
                return redirect()->to($request->getPost('url'))->with('error', 'Berhasil menghapus data barang!');
            }
        }
    }
    protected function insertBarangForm()
    {
        $request = service('request');
        $data = [
            "id" => null,
            "user_id" => (int)user()->id,
            "jenis" => $request->getPost('jenis'),
            "merk" => $request->getPost('merk'),
            "tipe" => $request->getPost('tipe'),
            "tahun_peroleh" => $request->getPost('tahun_peroleh'),
            "kondisi" => $request->getPost('kondisi'),
            "status" => $request->getPost('status'),
            "nomor_seri" => $request->getPost('nomor_seri'),
            "nib" => $request->getPost('nib'),
            "lokasi" => $request->getPost('lokasi'),
            "nip_pemakai" => $request->getPost('nip_pemakai'),


        ];
        return $this->tambahBarang($data);
    }

    // Kendaraan DInas
    public function kelola_kendaraandinas()
    {
        $it = new KendaraanDinasModel();
        $peg = new PegawaiModel();

        $data = [
            'barang'  => $it->getBarangById(),
            'daftar_nip' => $peg->getAllNip(),
            'title' => 'Daftar Kendaraan Dinas',
            'room_list' => $this->room_list,
            'merk_list' => $this->merk_kbm,
            "kondisi_list" => $this->kondisi_list,
            "type_list" => $this->type_list_kendaraan,
            "app_name" => $this->app_name,
            "page_name" => "Kelola Kendaraan Dinas",
            "uri" => $this->uri = service('uri')
        ];


        return view('user/kelola_kendaraandinas', $data);
    }

    public function tambah_kendaraan()
    {
        $kendaraan = new KendaraanDinasModel();
        $request = service('request');
        $data = [
            'id' => $this->insertBarangForm(),
            'nomor_plat' => $request->getPost('nomor_plat'),
            'besar_cc' => $request->getPost('besar_cc')
        ];
        $kendaraan->set($data);
        $kendaraan->insert();
        return redirect()->to($request->getPost('url'));
    }
    public function ubahKendaraanDinas()
    {
        $barangModel = new KendaraanDinasModel();

        $request = service("request");
        $id = $request->getPost("id");
        $data = [
            "merk" => $request->getPost('merk'),
            "tahun" => $request->getPost('tahun'),
            "kondisi" => $request->getPost('kondisi'),
            "nomor_seri" => $request->getPost('nomor_seri'),
            "nib" => $request->getPost('nib'),
            "lokasi" => $request->getPost('lokasi'),
            "nip_pemakai" => $request->getPost('nip_pemakai'),
            "tipe" => $request->getPost('tipe'),
            "nomor_plat" => $request->getPost('nomor_plat'),
            "besar_cc" => $request->getPost('besar_cc'),
        ];

        return $barangModel->update($id, $data);
    }
    public function hapusKendaraanDinas()
    {
        $request = service('request');
        $id = $request->getPost('id');

        $model = new KendaraanDinasModel();
        if (isset($id)) {
            $model->where('id', $id)->delete();
        }

        return 1;
    }
    public function kelola_pengguna()
    {
        $user = new PenggunaModel();

        $data = [

            'daftar_nip' => $user->getAllNip(),
            "users" => $user->getUser(null),
            'room_list' => $this->room_list,
            'fungsi_list' => $this->fungsi_list,
            "app_name" => $this->app_name,
            "page_name" => "Kelola Pengguna",
            "uri" => $this->uri = service('uri')
        ];
        return view('user/kelola_pengguna', $data);
    }
    public function tambah_pengguna()
    {
        $grup = new GrupModel();
        $pengguna = new PenggunaModel();

        $request = service('request');
        //"tahunPeroleh" => $request->getPost('tahunPeroleh'),
        $data = [
            "id" => null,
            "email" => $request->getPost('email'),
            "nip" => $request->getPost('nip'),
            "nama_lengkap" => $request->getPost('nama_lengkap'),
            "active" => 1,
            "bidang" => $request->getPost('bidang'),
            "password_hash" => password_hash($request->getPost('password'), PASSWORD_BCRYPT, ['cost' => 10]),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')

        ];

        #insert pengguna
        $pengguna->set($data);
        $pengguna->insert();
        if ($request->getPost('role') == 'admin') {
            #insert group
            $grup->set([
                'group_id' => 2,
                'user_id' => $pengguna->getInsertID()
            ]);
        } else {

            #insert group
            $grup->set([
                'group_id' => 5,
                'user_id' => $pengguna->getInsertID()
            ]);
        }
        $grup->insert();

        return redirect()->to($request->getPost('url'));
    }
    public function ubah_pengguna()
    {
        $grup = new GrupModel();
        $pengguna = new PenggunaModel();

        $request = service('request');
        //"tahunPeroleh" => $request->getPost('tahunPeroleh'),
        $user_id = $request->getPost('id');
        $data = [

            "email" => $request->getPost('email'),

            "nip" => $request->getPost('nip'),
            "nama_lengkap" => $request->getPost('nama_lengkap'),
            "bidang" => $request->getPost('bidang'),
            'updated_at' => date('Y-m-d H:i:s')

        ];
        if (strlen($request->getPost('password')) > 7) {
            $data["password_hash"] = password_hash($request->getPost('password'), PASSWORD_BCRYPT, ['cost' => 10]);
        }

        #update pengguna
        $pengguna->update($user_id, $data);

        if ($request->getPost('role') == 'admin') {

            $grup_id = 1;
        } else {

            $grup_id = 2;
        }
        $data_grup = [
            'group_id' => $grup_id
        ];
        $grup->update($user_id, $data_grup);


        return redirect()->to($request->getPost('url'))->with('message', 'Data pengguna berhasil diubah!');
    }
    public function hapus_pengguna()
    {
        $grup = new GrupModel();
        $pengguna = new PenggunaModel();

        $request = service('request');
        //"tahunPeroleh" => $request->getPost('tahunPeroleh'),
        $user_id = $request->getPost('id');
        $pengguna->where('id', $user_id)->delete();
        $grup->where('user_id', $user_id)->delete();
        return 1;
    }

    public function kelola_pengajuan()
    {
        $status = [
            "PENDING",
            "PROCESSED",
            "DONE"
        ];
        $model = new PengajuanModel();
        $nip = user()->nip;
        $pengajuan = $model->getListPengajuan(null);



        $data = [
            "pending" => $pengajuan['PENDING'],
            "processed" => $pengajuan['PROCESSED'],
            "done" => $pengajuan['DONE'],
            "title" => "Daftar Pengajuan Barang Saya",
            "status_list" => $status,
            "app_name" => $this->app_name,
            "page_name" => "Kelola Pengajuan",
            "uri" => $this->uri = service('uri')

        ];




        return view("user/kelola_pengajuan", $data);
    }
    public function pengguna_pengajuan()
    {
        $status = [
            "PENDING",
            "PROCESSED",
            "DONE"
        ];
        $model = new PengajuanModel();
        $id = user()->id;
        $pengajuan = $model->getListPengajuan($id);



        $data = [
            "pending" => $pengajuan['PENDING'],
            "processed" => $pengajuan['PROCESSED'],
            "done" => $pengajuan['DONE'],
            "title" => "Daftar Pengajuan Barang Saya",
            "status_list" => $status,
            "app_name" => $this->app_name,
            "page_name" => "Kelola Pengajuan",
            "uri" => $this->uri = service('uri')

        ];


        return view("user/pengguna_pengajuan", $data);
    }
    public function tambah_pengajuan($id = null)
    {
        $queri = new BarangModel();
        $request = service("request");
        $data = $queri->select('tipe,merk')
            ->where(['id' => $id])
            ->findAll()[0];


        $barang = [
            'id' => $id,
            'nama' => $data['merk'] . ' ' . $data['tipe'],
            'tipe' => 1,
        ];

        $data = [
            "id" => $id,
            "app_name" => $this->app_name,
            "page_name" => "Kelola Pengajuan",
            "uri" => $this->uri = service('uri'),
            "barang" => $barang

        ];
        return view("user/tambah_pengajuan", $data);
    }

    public function ubah_barangit_pengguna($id = null)
    {
        $it = new BarangITModel();
        $request = service("request");
        $data = $it->getBarangById($id)[0];
        if (user()->nip != $it->getBarangById($id)[0]['nip_pemakai']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }


        $data = [
            "id" => $id,
            "app_name" => $this->app_name,
            'jenis_list' => $this->jenis_list,
            'merk_list' => $this->merk_list,
            'tipe_list' => $this->tipe_list,
            'os_list' => $this->os_list,
            'room_list' => $this->room_list,
            "page_name" => "Kelola Pengajuan",
            "uri" => $this->uri = service('uri'),
            "barang" => $data

        ];
        return view("user/ubah_barangit_pengguna", $data);
    }
    public function pengajuan_detail($id = null)

    {

        if (is_null($id)) {
            $data = [
                "status" => 404,
                "pesan" => "Parameter ID tidak boleh null"
            ];
            return $this->respond($data);
        } else {
            $model = new PengajuanModel();
            $data = $model->select("id, status, created_at, start_date, end_date, keluhan")
                ->where(['id' => $id])
                ->findAll();

            return $this->respond([
                "status" => 200,
                "data" => $data
            ]);
        }
    }
    public function update_pending()
    {

        $pengajuan_model = new PengajuanModel();

        $request = service("request");
        $rawdate = htmlentities($request->getPost('start_date'));
        $date = date('Y-m-d', strtotime($rawdate));

        $data = [
            "status" => "PROCESSED",
            "start_date" => $date,
        ];
        $id = $request->getPost("id");
        $save = $pengajuan_model->update($id, $data);


        if ($save) {
            return redirect()->to($request->getPost('url'))->with('message', 'Memproses perawatan barang IT!');
        } else {
            return redirect()->to($request->getPost('url'))->with('error', 'Gagal memproses perawatan barang IT!');
        }
    }

    public function update_processed()
    {

        $pengajuan_model = new PengajuanModel();
        $barang = new BarangModel();

        $request = service("request");

        $data = [
            "status" => "DONE",
            "end_date" => $request->getPost('end_date'),
            "kondisi_final" => $request->getPost('kondisi_final'),
            "total_biaya" => $request->getPost('total_biaya'),
            "catatan_admin" => $request->getPost('catatan_admin'),
        ];
        $id = $request->getPost("id");
        $id_barang = $request->getPost('id_barang');

        $up =  $pengajuan_model->update($id, $data);
        $up2 = $barang->update($id_barang, ['kondisi' => $request->getPost('kondisi_final')]);
        if ($up && $up2) {
            return redirect()->to($request->getPost('url'))->with('message', 'Selesai memproses perawatan barang IT!');
        }
    }
    public function pengguna_barangit()
    {
        $it = new BarangITModel();
        $peg = new PegawaiModel();

        $data = [
            'barang'  => $it->getBarangByUser(user()->id),
            'nip' => user()->nip,
            'title' => 'Daftar Barang IT',

            'jenis_list' => $this->jenis_list,
            'merk_list' => $this->merk_list,
            'tipe_list' => $this->tipe_list,
            'os_list' => $this->os_list,
            'room_list' => $this->room_list,

            "app_name" => $this->app_name,
            "page_name" => "Barang IT Pengguna",
            "uri" => $this->uri = service('uri')
        ];
        return view('user/pengguna_barangit', $data);
    }
    public function pengguna_kendaraandinas()
    {
        $kd = new KendaraanDinasModel();

        $data = [
            'barang'  => $kd->getBarangById(user()->id),
            'nip' => user()->nip,
            'title' => 'Daftar Kendaraan Dinas',
            "app_name" => $this->app_name,
            "page_name" => "Barang IT Pengguna",
            "type_list" => $this->type_list_kendaraan,
            "merk_list" => $this->merk_kbm,
            "kondisi_list" => $this->kondisi_list,
            "room_list" => $this->room_list,
            "uri" => $this->uri = service('uri')
        ];
        return view('user/pengguna_kendaraandinas', $data);
    }
    public function ajukan()
    {
        $request = service("request");


        $model = new PengajuanModel();

        $data = [
            "id_barang" => $request->getPost('id_barang'),
            "tipe" => $request->getPost('tipe'),
            "keluhan" => $request->getPost('keluhan'),
        ];
        $model->save($data);
        return redirect()->to(base_url() . "/user/pengguna_barangit");
    }
}
