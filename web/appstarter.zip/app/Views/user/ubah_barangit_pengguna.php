<?= $this->extend('templates/index'); ?>

<?= $this->section('content'); ?>

<h4 class="text-center mt-5">Perubahan Data Barang IT</h4>

<div class="container w-70 mt-4">
    <form action="<?= esc(base_url('user/ubah_barangitByUser')); ?>" method="post" role="form">
        <?= csrf_field() ?>
        <div class="row form-group mb-3 d-none">
            <div class="col-5"><label class="col-form-label" for="id1">ID </label></div>
            <div class="col-7"><input type="text" class="form-control form-control-sm" name="id" value="<?= $barang['id'] ?>">
            </div>
        </div>
        <div class="row form-group mb-3">
            <div class="col-5"><label class="col-form-label" for="jenis">Jenis </label></div>
            <div class="col-7">
                <select class="form-select" name="jenis" required>
                    <?php foreach ($jenis_list as $jenis) : ?>
                        <option <?php echo ($barang['jenis'] == $jenis) ? 'selected = "selected"' : ''; ?>><?= esc($jenis) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="row form-group mb-3">
            <div class="col-5"><label class="col-form-label" for="tipe1">Tipe </label></div>
            <div class="col-7">
                <select class="form-select" name="tipe" required>
                    <?php foreach ($tipe_list as $tipe) : ?>
                        <option <?php echo ($barang['tipe'] == $tipe) ? 'selected = "selected"' : ''; ?>><?= esc($tipe) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="row form-group mb-3">
            <div class="col-5"><label class="col-form-label" for="merk1">Merk Barang</label></div>
            <div class="col-7">
                <select class="form-select" name="merk" required>
                    <?php foreach ($merk_list as $merk) : ?>
                        <option <?php echo ($barang['merk'] == $merk) ? 'selected = "selected"' : ''; ?>><?= esc($merk) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="row form-group mb-3">
            <div class="col-5"><label class="col-form-label" for="tahun1">Tahun Peroleh</label></div>
            <div class="col-7">
                <select name="tahun_peroleh" name="tahun_peroleh" class="form-select">
                    <?php
                    $e = (int)date("Y");
                    for ($x = $e; $x >= ($e - 15); $x -= 1) : ?>
                        <option <?php echo ($barang['tahun_peroleh'] == $x) ? 'selected = "selected"' : ''; ?>><?= esc($x) ?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>


        <div class="row form-group mb-3">
            <div class="col-5"><label class="col-form-label" for="kondisi1">Kondisi Barang</label></div>
            <div class="col-7">
                <select class="form-select" name="kondisi">

                    <option <?php echo ($barang['kondisi'] == "Baik") ? 'selected = "selected"' : ''; ?>>Baik</option>
                    <option <?php echo ($barang['kondisi'] == "Rusak Ringan") ? 'selected = "selected"' : ''; ?>>Rusak Ringan</option>
                    <option <?php echo ($barang['kondisi'] == "Rusak Berat") ? 'selected = "selected"' : ''; ?>>Rusak Berat</option>
                </select>
            </div>
        </div>

        <div class="row form-group mb-3">
            <div class="col-5"><label class="col-form-label" for="lokasi1">Lokasi Barang</label></div>
            <div class="col-7">
                <select name="lokasi" class="form-select">
                    <?php foreach ($room_list as $room) : ?>
                        <option <?php echo ($barang['lokasi'] == $room) ? 'selected = "selected"' : ''; ?>><?= esc($room) ?></option>
                    <?php endforeach; ?>

                </select>
            </div>
        </div>


        <div class="row form-group mb-3">
            <div class="col-5"><label class="col-form-label" for="os1">Sistem Operasi (OS)</label></div>
            <div class="col-7">
                <select name="os" class="form-select">
                    <?php foreach ($os_list as $os) : ?>
                        <option <?php echo ($barang['os'] == $os) ? 'selected = "selected"' : ''; ?>><?= esc($os) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row form-group mb-3">
            <div class="col-5"><label class="col-form-label" for="nomor-seri1">Nomor Seri</label></div>
            <div class="col-7"><input type="text" class="form-control" value="<?= $barang['nomor_seri'] ?>" name="nomor_seri" required></input>
            </div>
        </div>
        <div class="row form-group mb-3">
            <div class="col-5"><label class="col-form-label" for="nib1">NIB</label></div>
            <div class="col-7"><input type="text" class="form-control" value="<?= $barang['nib'] ?>" name="nib" required></input>
            </div>
        </div>
        <input name="url" type="text" class="d-none" value="<?= base_url('user/pengguna_barangit'); ?>">





        <div class="row form-group mb-3 offset-5">
            <div class="col-auto">
                <a href='<?= base_url('user/pengguna_barangit') ?>' class="btn btn-sm btn-sm btn-secondary">Kembali</a>
            </div>
            <div class="col-auto">
                <div class="col-7"><input type="submit" id="submit-edit" name="submit" class="btn btn-sm btn-sm btn-success" value="Simpah">
                </div>
            </div>

    </form>
</div>
<?= $this->endSection(); ?>