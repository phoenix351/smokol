<?= $this->extend('templates/index'); ?>

<?= $this->section('content'); ?>
<style>
    th {
        text-align: center;
        vertical-align: center;
    }
</style>

<h3>Rekap Perangkat Keras TIK Berdasarkan Kondisi</h3>

<div class="container my-4 table-responsive">
    <table class="table table-hover table-striped table-bordered">
        <thead>
            <tr>
                <th rowspan="2">Jenis</th>
                <th colspan="3">Kondisi Barang</th>
                <th rowspan="2">Total</th>
            </tr>
            <tr>
                <th>Baik</th>
                <th>Rusak Ringan</th>
                <th>Rusak Berat</th>

            </tr>
        </thead>

        <tbody>
            <?php foreach ($rekap_it as $row) : ?>
                <tr>
                    <td class="text-start"><?= esc($row['jenis']) ?></td>
                    <td class="text-end"><?= esc($row['Baik']) ?></td>
                    <td class="text-end"><?= esc($row['Rusak Ringan']) ?></td>
                    <td class="text-end"><?= esc($row['Rusak Berat']) ?></td>
                    <td class="text-end"><?= esc($row['Total']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<h3>Rekap Biaya Pemeliharaan Perangkat Keras TIK</h3>

<div class="container my-4 table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <th class="text-end">No</th>
            <th class="text-start">Jenis</th>
            <th class="text-start">Nama Barang</th>
            <th class="text-start">Nama Pemakai</th>
            <th class="text-end">Tahun</th>
            <th class="text-end">Total Biaya</th>
        </thead>
        <tbody>
            <?php $i = 1 ?>
            <?php foreach ($rekap_biaya as $rek) : ?>
                <tr>
                    <td class="text-end"><?= esc($i) ?></td>
                    <td class="text-start"><?= esc($rek['jenis']) ?></td>
                    <td class="text-start"><?= esc($rek['merk'] . ' ' . $rek['tipe']) ?></td>
                    <td class="text-start"><?= esc($rek['nama_pemakai']) ?></td>
                    <td class="text-end"><?= esc($rek['tahun']) ?></td>
                    <td class="text-end"><?= esc($rek['total_biaya']) ?></td>
                </tr>
            <?php endforeach; ?>

        </tbody>
    </table>
</div>
no jenis, nama barang, nama user, tahun,total biaya


<?= $this->endSection(); ?>