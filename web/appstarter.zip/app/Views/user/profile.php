<?= $this->extend('templates/index'); ?>

<?= $this->section('content'); ?>
<h2>Profil Pengguna</h2>
<div class="row">
    <div class="col-3">
        Nama Lengkap
    </div>
    <div class="col-9">
        <?= user()->nama_lengkap; ?>
    </div>
</div>
<div class="row">
    <div class="col-3">
        Email
    </div>
    <div class="col-9"><?= user()->email; ?></div>
</div>
<div class="row">
    <div class="col-3">Bidang</div>
    <div class="col-9"><?= user()->bidang; ?></div>
</div>
<div class="row">
    <div class="col-3">NIP</div>
    <div class="col-9"><?= user()->nip; ?></div>
</div>

<?= $this->endSection(); ?>