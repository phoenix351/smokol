<?= $this->extend('templates/index'); ?>

<?= $this->section('content'); ?>
<style>
    #daftar-pegawai {
        font-size: 0.93em;
    }


    .id {
        display: none;
    }
</style>
<!-- modal add form -->
<div class="modal fade" id="modal-add-barang" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-light" id="delete-modal-label">Tambah Data Barang</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <form action="<?= esc(base_url('user')); ?>/tambahBarangit" method="post" role="form">
                    <?= csrf_field() ?>

                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="jenis">Jenis</label>
                        </div>
                        <div class="col-7">
                            <select class="form-select" name="jenis" required>
                                <?php foreach ($jenis_list as $jenis) : ?>
                                    <option><?= esc($jenis) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="tipe">Tipe </label>
                        </div>
                        <div class="col-7">
                            <select class="form-select" name="tipe" required>
                                <?php foreach ($tipe_list as $tipe) : ?>
                                    <option><?= esc($tipe) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="merk">Merk Barang</label>
                        </div>
                        <div class="col-7">
                            <select class="form-select" name="merk" required>
                                <?php foreach ($merk_list as $merk) : ?>
                                    <option><?= esc($merk) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="tahun_peroleh">Tahun Peroleh</label>
                        </div>
                        <div class="col-7">
                            <select name="tahun_peroleh" class="form-select" required>
                                <?php
                                $e = (int)date("Y");
                                for ($x = $e; $x >= ($e - 15); $x -= 1) : ?>
                                    <option><?= esc($x) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                    </div>


                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="kondisi">Kondisi Barang</label>
                        </div>
                        <div class="col-7">
                            <select class="form-select" name="kondisi" required>
                                <option>Baik</option>
                                <option>Rusak Ringan</option>
                                <option>Rusak Berat</option>
                            </select>
                        </div>
                    </div>
                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="status">Status Barang</label>
                        </div>
                        <div class="col-7">
                            <select class="form-select" name="status" required>
                                <option>Operasional</option>
                                <option>Perbaikan</option>
                                <option>Tidak digunakan</option>
                            </select>
                        </div>
                    </div>
                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="lokasi">Lokasi Barang</label>
                        </div>
                        <div class="col-7">
                            <select name="lokasi" class="form-select" required>
                                <?php foreach ($room_list as $room) : ?>
                                    <option><?= esc($room) ?></option>
                                <?php endforeach; ?>

                            </select>
                        </div>
                    </div>


                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="os">Sistem Operasi (OS)</label>
                        </div>
                        <div class="col-7">
                            <select name="os" class="form-select">
                                <?php foreach ($os_list as $os) : ?>
                                    <option><?= esc($os) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="nomor_seri">Nomor Seri</label>
                        </div>
                        <div class="col-7">
                            <input type="text" class="form-control" name="nomor_seri" required></input>
                        </div>
                    </div>
                    <div class="row form-group mb-3">
                        <div class="col-5">
                            <label class="col-form-label" for="nib">NIB</label>
                        </div>
                        <div class="col-7">
                            <input type="text" class="form-control" name="nib" required></input>
                        </div>
                    </div>
                    <div class="row form-group mb-3 d-none">
                        <div class="col-5">
                            <label class="col-form-label" for="url">URL</label>
                        </div>
                        <div class="col-7">
                            <input type="text" class="form-control" name="url" value="<?= base_url($uri->getPath()); ?>" required>
                        </div>
                    </div>
                    <div class="row form-group mb-3 d-none">
                        <div class="col-5">
                            <label class="col-form-label" for="nip_pemakai">NIP Pemakai</label>
                        </div>
                        <div class="col-7">
                            <input type="text" class="form-control" name="nip_pemakai" value="<?= user()->nip; ?>">
                        </div>
                    </div>

            </div>



            <div class="modal-footer">
                <input type="button" class="btn btn-sm btn-sm btn-default" data-bs-dismiss="modal" value="Batalkan">
                <input type="submit" id="submit-add" class="btn btn-sm btn-sm btn-success" value="Simpan">
            </div>
            </form>
        </div>
    </div>
</div>

<!-- end modal add -->

<!-- Modal Kembalikan Barang -->
<div class="modal fade" id="modal-kembalikan-barang" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-light" id="edit-modal-label">Apakah Anda Yakin Akan Mengembalikan Barang Berikut Kepada Admin ? </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <form action=" <?= base_url('user') ?>/pengguna_balik_barang" method="post" role="form">
                    <?= csrf_field() ?>
                    <input type="text" name="barang_id" id="barang_id">
                    <div class="modal-footer">
                        <input type="button" class="btn btn-sm btn-sm btn-default" data-bs-dismiss="modal" value="Batalkan">
                        <input type="submit" name="submit" class="btn btn-sm btn-sm btn-success" value="Konfirmasi">
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>


<!-- End modal Kembalikan Barang -->

<!-- Modal pengajuan form -->
<div class="modal fade" id="modal-edit-barang" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-light" id="edit-modal-label">Pengajuan Keluhan Barang</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('user') ?>/ajukan" method="post" role="form">
                    <?= csrf_field() ?>
                    <div class="row form-group mb-3">
                        <label class="col-form-label" for="id_barang">ID Barang</label>
                        <input type="text" id="id1" name="id_barang" class="form-control form-control-sm">
                    </div>
                    <div class="row form-group mb-3">
                        <label class="col-form-label" for="type">Type Barang</label>
                        <input type="text" name="type" class="form-control form-control-sm" value="1">
                    </div>
                    <div class="row form-group mb-3">
                        <label class="col-form-label" for="complain">Keluhan</label>
                        <textarea name="complain" cols=" 30" rows="10" class="form form-control form-control-sm"></textarea>
                    </div>

            </div>


            <div class="modal-footer">
                <input type="button" class="btn btn-sm btn-sm btn-default" data-bs-dismiss="modal" value="Batalkan">
                <input type="submit" id="submit-edit" name="submit" class="btn btn-sm btn-sm btn-success" value="Ajukan">
            </div>
            </form>

        </div>
    </div>
</div>
<!-- end modal pengajuan -->





<h2><?php echo esc($title); ?></h2>


<button href="#" class="btn btn-sm btn-sm btn-success mb-3 mt-2" id="tambah-barang">Tambah Barang</button>
<?= view('Myth\Auth\Views\_message_block') ?>
<div class="table-responsive">
    <table class="table table-hover" id="daftar-barang" data-search="false" data-striped="true" data-pagination="true" data-filter-control="true" data-side-pagination="client" data-page-size="10" data-page-list="[10, 25, 50, 100, ALL]">
        <thead>
            <tr>
                <th class="id">ID Barang</th>
                <th data-filter-control="input" data-field="Jenis Barang">Jenis Barang</th>
                <th data-filter-control="input" data-field="Nama Barang">Nama Barang</th>
                <th data-filter-control="input" data-field="Tipe">Tipe</th>
                <th data-filter-control="input" data-field="Merk">Merk</th>
                <th data-filter-control="input" data-field="OS">OS</th>
                <th data-filter-control="input" data-field="Tahun Peroleh">Tahun Peroleh</th>
                <th data-filter-control="input" data-field="Lokasi Barang">Lokasi Barang</th>
                <th data-filter-control="input" data-field="Kondisi">Kondisi</th>
                <th class="text-center">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($barang as $brg) : ?>
                <tr>

                    <td class="id"><?= esc($brg['id']); ?></td>
                    <td class="jenis"><?= esc($brg['jenis']); ?></td>
                    <td class="nama"><?= esc($brg['merk'] . ' ' . $brg['tipe']); ?></td>
                    <td class="tipe"><?= esc($brg['tipe']); ?></td>
                    <td class="merk"><?= esc($brg['merk']); ?></td>
                    <td class="os"><?= esc($brg['os']); ?></td>
                    <td class="tahun"><?= esc($brg['tahun_peroleh']); ?></td>
                    <td class="lokasi"><?= esc($brg['lokasi']); ?></td>
                    <td class="kondisi"><?= esc($brg['kondisi']); ?></td>
                    <td class="text-center">
                        <div class="row">
                            <form action="<?= base_url('user') ?>/tambah_pengajuan/<?= esc($brg['id']); ?>" method="get" role="form">
                                <button class="btn btn-sm w-100 btn-success" type="submit">Pengajuan</button>
                            </form>
                        </div>
                        <div class="row">
                            <form action="<?= base_url('user') ?>/ubah_barangit_pengguna/<?= esc($brg['id']); ?>" method="get" role="form">
                                <button class="btn btn-sm w-100 btn-primary" type="submit">Ubah</button>
                            </form>
                        </div>
                        <div class="row">
                            <button class="btn btn-danger" onclick="Kembalikan(this)">Kembalikan</button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>

        </tbody>
    </table>
</div>

<script>
    $(document).ready(function() {
        $('#daftar-barang').bootstrapTable();
        $('#tambah-barang').click(function() {
            $("#modal-add-barang").modal('show');
        });


    });

    function Kembalikan(t) {
        let row = $(t).closest("tr");
        // ambil data
        let id = row.find(".id").text();
        // insert data dan buka modal 
        $("#barang_id").val(id);
        $("#modal-kembalikan-barang").modal('show');

    };
    // edit employee
</script>


<?= $this->endSection(); ?>