<?php

namespace App\Models;

use CodeIgniter\Model;

class BarangModel extends Model
{
    protected $table = 'barang';
    protected $allowedFields = [
        'id', 'jenis', 'merk', "user_id", "tahun_peroleh", "kondisi",
        'status', "nomor_seri", "nib", "lokasi", "nip_pemakai",
        "tipe", 'created_at', 'updated_at'
    ];
    protected $primaryKey = "id";
    public function getKondisiSum($id = null)
    {
        $ret = [
            'Baik' => 0,
            'Rusak Ringan' => 0,
            'Rusak Berat' => 0,
            'Total' => 0
        ];
        if (is_null($id)) {
            $data =  $this->asArray()
                ->select('kondisi,count(id) as jumlah')
                ->groupBy('kondisi')
                ->findAll();
        } else {
            $data =  $this->asArray()
                ->select('kondisi,count(id) as jumlah')
                ->where(['user_id' => $id])
                ->groupBy('kondisi')
                ->findAll();
        }
        foreach ($data as $d) {
            $ret[$d['kondisi']] = $d['jumlah'];
        }
        $ret['Total'] = $ret['Baik'] + $ret['Rusak Ringan'] + $ret['Rusak Berat'];
        return $ret;
    }
    public function balik_barang_pengguna($id)
    {

        $data = [
            "user_id" => 5
        ];


        $up  = $this->update($id, $data);
    }
}
