<?php

namespace App\Models;

use CodeIgniter\Model;


class PenggunaModel extends Model
{
    protected $primaryKey = "id";
    protected $allowedFields = ['id', "nama_lengkap", "email", "nip", "bidang", "password_hash", "active"];
    protected $table = 'users';

    public function getUser($id = null)
    {
        if (is_null($id)) {
            return $this->select('users.id as id,nama_lengkap ,email,nip,bidang,active,auth_groups.name as role')
                ->join('auth_groups_users', 'users.id = auth_groups_users.user_id')
                ->join('auth_groups', 'auth_groups_users.group_id = auth_groups.id')
                ->findAll();
        } else {
            return $this->select('users.id as id,nama_lengkap ,email,nip,bidang,active,auth_groups.name as role')
                ->join('auth_groups_users', 'users.id = auth_groups_users.user_id')
                ->join('auth_groups', 'auth_groups_users.group_id = auth_groups.id')
                ->where(['id' => $id])
                ->findAll();
        }
    }
    public function getAllNip()
    {
        return $this->select('nip')
            ->findAll();
    }
}
