<?php

namespace App\Models;

use CodeIgniter\Model;

class BarangITModel extends Model
{
    protected $table = 'barang_it';
    protected $allowedFields = [
        'id', "os"
    ];
    protected $primaryKey = "id";

    public function getBarangById($id = null)
    {
        if (is_null($id)) {
            return $this->select('barang.id as id, users.nama_lengkap,barang.jenis,nomor_seri, nib,tipe,merk,kondisi,barang.status,tahun_peroleh,lokasi,barang.created_at,barang.updated_at,os')
                ->join('barang', 'barang_it.id=barang.id')
                ->join('users', 'barang.user_id=users.id')
                ->findAll();
        } else {
            return $this->select('barang.id as id ,barang.jenis,nomor_seri,nip_pemakai,nama_lengkap,nib,tipe,merk,kondisi,barang.status,tahun_peroleh,lokasi,barang.created_at,barang.updated_at,os')
                ->join('barang', 'barang_it.id=barang.id')
                ->join('users', 'barang.user_id=users.id')
                ->where(['barang.id' => $id])
                ->findAll();
        }
    }
    public function getBarangByUser($id = null)
    {
        if (is_null($id)) {
            return $this->select('barang.id as id ,barang.jenis,nomor_seri, nib,tipe,merk,kondisi,barang.status,tahun_peroleh,lokasi,barang.created_at,barang.updated_at,os')
                ->join('barang', 'barang_it.id=barang.id')
                ->join('users', 'barang.user_id=users.id')
                ->findAll();
        } else {
            return $this->select('barang.id as id ,barang.jenis,nomor_seri,nip_pemakai,nama_lengkap,nib,tipe,merk,kondisi,barang.status,tahun_peroleh,lokasi,barang.created_at,barang.updated_at,os')
                ->join('barang', 'barang_it.id=barang.id')
                ->join('users', 'barang.user_id=users.id')
                ->where(['barang.user_id' => $id])
                ->findAll();
        }
    }
    public function getRekap()
    {
        $arr = $this->asArray()
            ->select('jenis, kondisi, count(barang.id) as jumlah')
            ->join('barang', 'barang.id=barang_it.id')
            ->groupBy('jenis, kondisi')
            ->findAll();
        $result = [];

        foreach ($arr as $elem) {
            $jenis = $elem['jenis'];
            if (!isset($result[$jenis])) {
                $result[$jenis] = [
                    "jenis" => $jenis
                ];
            }
            $result[$jenis][$elem['kondisi']] = $elem['jumlah'];
        }
        $indeks = 0;
        $hasil = [];
        foreach ($result as $e) {
            if (!isset($e['Baik'])) {
                $e['Baik'] = 0;
            }
            if (!isset($e['Rusak Ringan'])) {
                $e['Rusak Ringan'] = 0;
            }
            if (!isset($e['Rusak Berat'])) {
                $e['Rusak Berat'] = 0;
            }
            $e['Total'] = $e['Baik'] + $e['Rusak Berat'] + $e['Rusak Ringan'];
            $hasil[$indeks] = $e;
            $indeks++;
        }
        return $hasil;
    }
    public function getRekapBiaya()
    {

        return $this->select('barang.jenis, barang.merk,barang.tipe, users.nama_lengkap as nama_pemakai, YEAR(perawatan_barang.start_date) as tahun, sum(perawatan_barang.biaya) as total_biaya')
            ->join('barang', 'barang.id=barang_it.id')
            ->join('perawatan_barang', 'barang.id=perawatan_barang.id_barang')
            ->join('users', 'barang.nip_pemakai=users.nip')
            ->groupBy('tahun')
            ->findAll();
    }

    public function getKondisiSum($nip = null)
    {
        $ret = [
            'Baik' => 0,
            'Rusak Ringan' => 0,
            'Rusak Berat' => 0,
            'total' => 0
        ];
        if (is_null($nip)) {
            $data =  $this->asArray()
                ->select('kondisi,count(barang.id) as jumlah')
                ->join('barang', 'barang_it.id=barang.id')
                ->groupBy('kondisi')
                ->findAll();
        } else {
            $data =  $this->asArray()
                ->select('kondisi,count(id) as jumlah')
                ->join('barang', 'barang_it.id=barang.id')
                ->where(['nip_pemakai' => $nip])
                ->groupBy('kondisi')
                ->findAll();
        }
        foreach ($data as $d) {
            $ret[$d['kondisi']] = $d['jumlah'];
        }
        $ret['total'] = $ret['Baik'] + $ret['Rusak Ringan'] + $ret['Rusak Berat'];
        return $ret;
    }
}
